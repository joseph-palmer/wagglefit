#!/usr/bin/env python3
"""Global variables for honeybee foraging simulation model"""
__appname__  = "config.py"
__author__   = "Joseph Palmer <joseph.palmer18@imperial.ac.uk>"
__version__  = "0.0.2"
__date__     = "02-2020"

FLOWERDICT = {}
BROADCASTED_DANCES = {}
